library(testthat)
library(workboots)

test_check("workboots")
