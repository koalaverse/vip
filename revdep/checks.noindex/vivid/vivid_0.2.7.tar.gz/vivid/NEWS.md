# vivid 0.2.7

* Added more examples to documentation and clarified documentation text
* Added more examples to the vignette
* Fixed typos in vignette

