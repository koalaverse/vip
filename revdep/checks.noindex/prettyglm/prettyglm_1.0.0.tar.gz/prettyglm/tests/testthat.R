library(testthat)
library(prettyglm)

test_check("prettyglm")
