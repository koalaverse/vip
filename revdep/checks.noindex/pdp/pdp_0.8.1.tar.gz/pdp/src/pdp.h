#include <Rinternals.h>
#include <Rconfig.h>

void in_out(double *bx, double *by, double *break_code, double *x, double *y,
            int *in, int *nb, int *n);
