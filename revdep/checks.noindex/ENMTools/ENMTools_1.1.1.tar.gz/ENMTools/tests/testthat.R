library(testthat)
library(ENMTools)

test_check("ENMTools")
