# This file is part of the standard setup for testthat.
# It is recommended that you do not modify it.

library(testthat)
library(SAEforest)

test_check("SAEforest")
