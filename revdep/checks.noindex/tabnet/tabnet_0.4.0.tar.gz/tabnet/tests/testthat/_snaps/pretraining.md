# print module works

    An `nn_module` containing 13,894 parameters.
    
    -- Modules ---------------------------------------
    * initial_bn: <nn_batch_norm1d> #146 parameters
    * embedder: <embedding_generator> #283 parameters
    * embedder_na: <na_embedding_generator> #0 parameters
    * masker: <random_obfuscator> #0 parameters
    * encoder: <tabnet_encoder> #10,304 parameters
    * decoder: <tabnet_decoder> #3,160 parameters
    
    -- Parameters ------------------------------------
    * .check: Float [1:1]

