# print module works even after a reload from disk

    An `nn_module` containing 10,742 parameters.
    
    -- Modules ---------------------------------------
    * embedder: <embedding_generator> #283 parameters
    * embedder_na: <na_embedding_generator> #0 parameters
    * tabnet: <tabnet_no_embedding> #10,458 parameters
    
    -- Parameters ------------------------------------
    * .check: Float [1:1]

---

    An `nn_module` containing 10,742 parameters.
    
    -- Modules ---------------------------------------
    * embedder: <embedding_generator> #283 parameters
    * embedder_na: <na_embedding_generator> #0 parameters
    * tabnet: <tabnet_no_embedding> #10,458 parameters
    
    -- Parameters ------------------------------------
    * .check: Float [1:1]

