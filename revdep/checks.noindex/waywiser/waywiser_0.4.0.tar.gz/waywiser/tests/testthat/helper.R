if (identical(Sys.getenv("NOT_CRAN"), "true")) {
  Sys.setenv("waywiser_test_cast" = "true")
}
