delayedAssign("ny_trees", local({
  requireNamespace("sf", quietly = TRUE)
  waywiser:::ny_trees
}))
