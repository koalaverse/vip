delayedAssign("guerry", local({
  requireNamespace("sf", quietly = TRUE)
  waywiser:::guerry
}))
